# SR17018 Website - Railway Deployment Guide

**Author:** Manus AI  
**Last Updated:** November 24, 2025

This comprehensive guide walks you through deploying your SR17018 e-commerce website to Railway, a modern cloud platform that provides seamless deployment for full-stack applications with integrated database support.

---

## Table of Contents

1. [Prerequisites](#prerequisites)
2. [Project Overview](#project-overview)
3. [Step-by-Step Deployment](#step-by-step-deployment)
4. [Database Setup](#database-setup)
5. [Environment Configuration](#environment-configuration)
6. [Custom Domain Setup](#custom-domain-setup)
7. [Post-Deployment Tasks](#post-deployment-tasks)
8. [Troubleshooting](#troubleshooting)
9. [Cost Estimation](#cost-estimation)

---

## Prerequisites

Before deploying to Railway, ensure you have the following prepared:

**Required Accounts:**
- **Railway account** - Sign up at [railway.app](https://railway.app)
- **GitHub account** - Your code will be deployed from a GitHub repository
- **Domain registrar account** - For BSRInnovations.com (if using custom domain)

**Required Tools:**
- **Git** - For version control and pushing code to GitHub
- **Code editor** - VS Code, Sublime Text, or similar

**Payment Information:**
- Credit card for Railway billing (starts with $5 free credit)
- Estimated cost: $10-20/month for this application

---

## Project Overview

Your SR17018 website is a full-stack e-commerce application with the following architecture:

| Component | Technology | Purpose |
|-----------|-----------|---------|
| **Frontend** | React 19 + Vite | User interface and product catalog |
| **Backend** | Express.js + tRPC | API server and business logic |
| **Database** | MySQL | Products, orders, and shipping data |
| **Authentication** | Manus OAuth (optional) | User and admin authentication |
| **Styling** | Tailwind CSS 4 | Responsive design system |
| **Build Tool** | Vite + esbuild | Fast builds and bundling |

**Key Features:**
- Product catalog with tiered pricing
- Shopping cart with localStorage persistence
- Checkout flow with Zelle/Bitcoin payment options
- Automatic free shipping for 3g, 5g, 10g orders
- Admin dashboard for order management
- Research disclaimer compliance

---

## Step-by-Step Deployment

### Step 1: Download Your Website Code

First, you need to download all the project files from the Management UI:

1. Open the **Management UI** panel (right side of this chat)
2. Click on **Code** in the left sidebar
3. Click the **Download** button at the top
4. Save the ZIP file to your computer
5. Extract the ZIP file to a folder (e.g., `sr17018-website`)

### Step 2: Initialize Git Repository

Open your terminal or command prompt and navigate to the extracted folder:

```bash
cd path/to/sr17018-website
git init
git add .
git commit -m "Initial commit - SR17018 website"
```

### Step 3: Create GitHub Repository

1. Go to [github.com](https://github.com) and log in
2. Click the **+** icon in the top right → **New repository**
3. Name it `sr17018-website` (or any name you prefer)
4. Keep it **Private** (recommended for e-commerce)
5. Do **NOT** initialize with README, .gitignore, or license
6. Click **Create repository**

### Step 4: Push Code to GitHub

Copy the commands from GitHub's "push an existing repository" section:

```bash
git remote add origin https://github.com/YOUR-USERNAME/sr17018-website.git
git branch -M main
git push -u origin main
```

Replace `YOUR-USERNAME` with your actual GitHub username.

### Step 5: Create Railway Project

1. Go to [railway.app](https://railway.app) and sign in
2. Click **New Project**
3. Select **Deploy from GitHub repo**
4. Authorize Railway to access your GitHub account
5. Select the `sr17018-website` repository
6. Railway will automatically detect it as a Node.js project

### Step 6: Add MySQL Database

Your application requires a MySQL database for storing products, orders, and shipping information.

1. In your Railway project dashboard, click **+ New**
2. Select **Database** → **Add MySQL**
3. Railway will provision a MySQL database
4. The `DATABASE_URL` environment variable will be automatically added

### Step 7: Configure Environment Variables

Click on your web service (not the database), then go to the **Variables** tab.

Add the following required variables:

| Variable Name | Value | How to Generate |
|--------------|-------|-----------------|
| `JWT_SECRET` | Random string | Run: `openssl rand -base64 32` |
| `VITE_APP_TITLE` | SR17018 Research Compound | Your site title |
| `VITE_APP_LOGO` | /logo.svg | Path to your logo |
| `NODE_ENV` | production | Fixed value |
| `PORT` | 3000 | Fixed value |

**Note:** The `DATABASE_URL` is automatically set by Railway when you add the MySQL service.

### Step 8: Seed the Database

After the first deployment, you need to populate the database with products and shipping rates.

**Option A: Using Railway CLI**

1. Install Railway CLI:
   ```bash
   npm install -g @railway/cli
   ```

2. Link your project:
   ```bash
   railway link
   ```

3. Run the seed script:
   ```bash
   railway run node seed-db.mjs
   ```

**Option B: Manual Database Population**

1. In Railway dashboard, click on your MySQL service
2. Go to the **Data** tab
3. Click **Query** and run the SQL commands from the seed script (see `seed-db.mjs` file)

### Step 9: Deploy and Verify

1. Railway automatically deploys your application
2. Wait for the build to complete (usually 2-5 minutes)
3. Click the **generated URL** (e.g., `sr17018-website-production.up.railway.app`)
4. Verify the website loads correctly

---

## Database Setup

### Initial Schema Migration

The database schema is automatically created on first deployment through Drizzle ORM. However, you need to populate it with initial data.

**Tables Created:**
- `users` - Customer and admin accounts
- `products` - SR17018 product variants (1g, 3g, 5g, 10g)
- `orders` - Customer orders
- `order_items` - Individual items in each order
- `shipping_rates` - UPS and USPS shipping options

### Seeding Products and Shipping Rates

The `seed-db.mjs` script populates your database with:

**Products:**
- SR17018 - 1 gram: $60.00
- SR17018 - 3 grams: $180.00 (FREE shipping)
- SR17018 - 5 grams: $290.00 (FREE shipping)
- SR17018 - 10 grams: $490.00 (FREE shipping)

**Shipping Rates:**
- USPS First Class Mail: $5.00
- USPS Priority Mail: $9.00
- UPS Ground: $12.00
- UPS 2nd Day Air: $18.00 (FREE for 3g, 5g, 10g)
- UPS Next Day Air: $35.00

### Database Backups

Railway automatically backs up your MySQL database. To manually export:

1. Go to MySQL service in Railway dashboard
2. Click **Data** tab
3. Click **Export** to download a SQL dump

---

## Environment Configuration

### Required Variables Explained

**DATABASE_URL**  
Automatically provided by Railway's MySQL service. Format:
```
mysql://user:password@host:port/database
```

**JWT_SECRET**  
Used to sign authentication tokens. Generate a secure random string:
```bash
openssl rand -base64 32
```
Example output: `xK8mP2vN9qR5sT7wY3zA6bC1dE4fG8hJ0kL2mN5oP7qR9sT1uV3wX6yZ8aB0cD2e`

**VITE_APP_TITLE**  
Your website's title, displayed in the browser tab and header.

**VITE_APP_LOGO**  
Path to your logo file (must be in `client/public/` folder).

**NODE_ENV**  
Set to `production` for Railway deployment.

**PORT**  
Railway automatically assigns a port, but the app defaults to 3000.

### Optional Variables

**Authentication (Manus OAuth)**  
If you want to keep Manus OAuth for user authentication, you'll need to contact Manus support for API credentials. Otherwise, you'll need to implement your own authentication system (Auth0, Clerk, Firebase Auth, etc.).

**S3 Storage (File Uploads)**  
If you want to upload product images or other files:
```
AWS_ACCESS_KEY_ID=your-access-key
AWS_SECRET_ACCESS_KEY=your-secret-key
AWS_REGION=us-east-1
AWS_S3_BUCKET=your-bucket-name
```

---

## Custom Domain Setup

### Connecting BSRInnovations.com

Once your Railway deployment is successful, you can connect your custom domain.

**Step 1: Configure Railway**

1. In Railway dashboard, click on your web service
2. Go to **Settings** tab
3. Scroll to **Domains** section
4. Click **+ Custom Domain**
5. Enter `bsrinnovations.com`
6. Railway will provide DNS records (CNAME or A record)

**Step 2: Configure DNS at Your Registrar**

Example for Namecheap:

1. Log in to Namecheap
2. Go to **Domain List** → click **Manage** next to BSRInnovations.com
3. Go to **Advanced DNS** tab
4. Add the records provided by Railway:

| Type | Host | Value | TTL |
|------|------|-------|-----|
| CNAME | www | your-app.up.railway.app | Automatic |
| CNAME | @ | your-app.up.railway.app | Automatic |

**Step 3: Add www Subdomain (Optional)**

To support both `bsrinnovations.com` and `www.bsrinnovations.com`:

1. Add both domains in Railway
2. Set up redirect from www to non-www (or vice versa)

**Step 4: Wait for DNS Propagation**

DNS changes can take 15 minutes to 48 hours to propagate globally. Check status:
```bash
dig bsrinnovations.com
```

**Step 5: Enable HTTPS**

Railway automatically provisions SSL certificates via Let's Encrypt once DNS is configured. This usually happens within 10-15 minutes.

---

## Post-Deployment Tasks

### 1. Update Payment Information

Edit the order confirmation page to include your actual payment details:

**File:** `client/src/pages/OrderConfirmation.tsx`

Find and replace:
```typescript
// Replace this placeholder email
const zelleEmail = "payments@sr17018.com";

// Replace this placeholder Bitcoin address
const btcAddress = "1A1zP1eP5QGefi2DMPTfTL5SLmv7DivfNa";
```

With your actual Zelle email and Bitcoin wallet address.

After making changes:
```bash
git add .
git commit -m "Update payment credentials"
git push
```

Railway will automatically redeploy.

### 2. Test Complete Order Flow

1. Browse to your website
2. Add a product to cart (try 3g for free shipping)
3. Proceed to checkout
4. Fill out customer information
5. Select shipping method (verify free shipping applies)
6. Choose payment method
7. Place order
8. Verify order confirmation displays correct payment info

### 3. Access Admin Dashboard

To manage orders:

1. Go to `https://yourdomain.com/admin`
2. Log in with admin credentials
3. View and update order statuses
4. Mark payments as received
5. Add tracking numbers for shipped orders

**Creating Admin Users:**

By default, the first user to sign up becomes an admin. To manually promote users to admin:

1. In Railway, click on MySQL service
2. Go to **Data** tab
3. Run this SQL query:
```sql
UPDATE users SET role = 'admin' WHERE email = 'your-email@example.com';
```

### 4. Set Up Monitoring

Railway provides built-in monitoring:

1. Click on your web service
2. Go to **Metrics** tab
3. Monitor CPU, memory, and network usage
4. Set up alerts for downtime or errors

### 5. Configure Backups

Railway automatically backs up your database, but you should also:

1. Export database weekly (Data tab → Export)
2. Store backups in a secure location
3. Test restoration process periodically

---

## Troubleshooting

### Build Failures

**Error: "Module not found"**

Solution: Ensure all dependencies are in `package.json`:
```bash
pnpm install
git add package.json pnpm-lock.yaml
git commit -m "Update dependencies"
git push
```

**Error: "Build command failed"**

Check Railway logs:
1. Click on your service
2. Go to **Deployments** tab
3. Click on the failed deployment
4. Review build logs for specific errors

### Database Connection Issues

**Error: "Cannot connect to database"**

1. Verify `DATABASE_URL` is set correctly
2. Check that MySQL service is running
3. Ensure your web service is linked to the database:
   - Go to your web service
   - Click **Variables** tab
   - Verify `DATABASE_URL` references the MySQL service

**Error: "Table doesn't exist"**

Run database migrations:
```bash
railway run pnpm db:push
```

### Application Crashes

**Error: "Application error" or 503**

1. Check logs in Railway dashboard
2. Common issues:
   - Missing environment variables
   - Database not seeded
   - Port binding issues

**Fix port binding:**

Ensure your `server/_core/index.ts` uses Railway's PORT:
```typescript
const PORT = process.env.PORT || 3000;
```

### Authentication Issues

**Error: "OAuth callback failed"**

If using Manus OAuth, you need to update callback URLs or implement your own auth system.

**Alternative:** Remove authentication requirement:
- Modify `server/routers.ts` to use `publicProcedure` instead of `protectedProcedure`
- This makes the site public (not recommended for admin functions)

### Free Shipping Not Applying

**Issue:** Free shipping doesn't show for 3g, 5g, 10g orders

1. Verify products are seeded correctly:
```sql
SELECT * FROM products;
```

2. Check shipping rates table:
```sql
SELECT * FROM shipping_rates WHERE carrier = 'UPS' AND serviceName = 'UPS 2nd Day Air';
```

3. Clear browser cache and test again

---

## Cost Estimation

### Railway Pricing Breakdown

Railway uses a **pay-as-you-go** model based on resource usage:

| Resource | Usage | Estimated Cost |
|----------|-------|----------------|
| **Web Service** | 512MB RAM, 0.5 vCPU | $5-10/month |
| **MySQL Database** | 1GB storage, shared CPU | $5-10/month |
| **Bandwidth** | ~10GB/month (low traffic) | Included |
| **Build Minutes** | ~50 builds/month | Included |

**Total Estimated Cost:** $10-20/month for low-to-medium traffic

### Cost Optimization Tips

1. **Use Railway's free tier credits** - Start with $5 free credit
2. **Monitor resource usage** - Check Metrics tab regularly
3. **Optimize images** - Compress product images to reduce bandwidth
4. **Enable caching** - Reduce database queries
5. **Scale down during low traffic** - Adjust resources in Settings

### Comparison to Other Platforms

| Platform | Monthly Cost | Pros | Cons |
|----------|-------------|------|------|
| **Railway** | $10-20 | All-in-one, easy setup | Can get expensive at scale |
| **Vercel + DB** | $20-50 | Best performance | Serverless limitations |
| **Render** | $14-25 | Predictable pricing | Free tier sleeps |
| **Manus** | Contact support | Integrated, no setup | Unknown pricing |

---

## Additional Resources

### Railway Documentation
- [Railway Docs](https://docs.railway.app/)
- [MySQL Service Guide](https://docs.railway.app/databases/mysql)
- [Environment Variables](https://docs.railway.app/develop/variables)

### Support Channels
- **Railway Discord:** [discord.gg/railway](https://discord.gg/railway)
- **Railway Support:** support@railway.app
- **GitHub Issues:** Create issues in your repository

### Next Steps

1. **Add Product Images:** Upload images to improve visual appeal
2. **Set Up Email Notifications:** Configure SMTP for order confirmations
3. **Implement Analytics:** Add Google Analytics or Plausible
4. **SEO Optimization:** Add meta tags and sitemap
5. **Payment Gateway:** Consider integrating Stripe or PayPal for automated payments

---

## Conclusion

Your SR17018 e-commerce website is now successfully deployed on Railway! The platform provides a robust infrastructure for your full-stack application with integrated database support, automatic deployments, and scalable resources.

**Key Takeaways:**
- Railway handles infrastructure so you can focus on your business
- Automatic deployments from GitHub streamline updates
- Built-in database backups protect your data
- Custom domain support for professional branding
- Scalable resources grow with your traffic

For ongoing support and updates, refer to this guide and Railway's documentation. Your website is now ready to serve customers and process orders for SR17018 research compound.

---

**Document Version:** 1.0  
**Author:** Manus AI  
**Date:** November 24, 2025
