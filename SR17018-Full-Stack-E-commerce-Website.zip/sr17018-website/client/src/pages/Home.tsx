import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { AlertCircle, Beaker, ShieldCheck, Truck } from "lucide-react";
import { Link } from "wouter";
import { APP_TITLE } from "@/const";

export default function Home() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-secondary">
      {/* Header */}
      <header className="border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center justify-between">
          <div className="flex items-center gap-2">
            <Beaker className="h-6 w-6 text-primary" />
            <h1 className="text-xl font-bold">{APP_TITLE}</h1>
          </div>
          <nav className="flex items-center gap-4">
            <Link href="/products">
              <Button variant="ghost">Products</Button>
            </Link>
            <Link href="/cart">
              <Button variant="ghost">Cart</Button>
            </Link>
          </nav>
        </div>
      </header>

      {/* Hero Section */}
      <section className="container py-20">
        <div className="mx-auto max-w-4xl text-center">
          <div className="mb-6 inline-flex items-center gap-2 rounded-full bg-primary/10 px-4 py-2 text-sm font-medium text-primary">
            <AlertCircle className="h-4 w-4" />
            For Research Purposes Only
          </div>
          <h2 className="mb-6 text-5xl font-bold tracking-tight">
            SR17018 Research Compound
          </h2>
          <p className="mb-8 text-xl text-muted-foreground">
            High-purity research compound available in multiple quantities for laboratory and scientific research applications.
          </p>
          <div className="flex justify-center gap-4">
            <Link href="/products">
              <Button size="lg" className="text-lg">
                Browse Products
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Research Disclaimer */}
      <section className="container py-12">
        <Card className="border-destructive/50 bg-destructive/5">
          <CardContent className="pt-6">
            <div className="flex items-start gap-4">
              <AlertCircle className="h-6 w-6 text-destructive flex-shrink-0 mt-1" />
              <div>
                <h3 className="text-lg font-semibold mb-2 text-destructive">
                  Important Research Notice
                </h3>
                <p className="text-sm text-muted-foreground">
                  SR17018 is intended strictly for research and laboratory use only. This product is not for human consumption, 
                  medical use, or any other application outside of controlled scientific research environments. By purchasing 
                  this product, you acknowledge that you are a qualified researcher and will use this compound in accordance 
                  with all applicable laws and regulations.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </section>

      {/* Features */}
      <section className="container py-16">
        <div className="grid gap-8 md:grid-cols-3">
          <Card>
            <CardContent className="pt-6">
              <div className="mb-4 inline-flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10">
                <Beaker className="h-6 w-6 text-primary" />
              </div>
              <h3 className="mb-2 text-lg font-semibold">High Purity</h3>
              <p className="text-sm text-muted-foreground">
                Laboratory-grade compound suitable for scientific research applications.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="mb-4 inline-flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10">
                <Truck className="h-6 w-6 text-primary" />
              </div>
              <h3 className="mb-2 text-lg font-semibold">Multiple Shipping Options</h3>
              <p className="text-sm text-muted-foreground">
                Choose from USPS and UPS shipping methods to meet your delivery needs.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="mb-4 inline-flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10">
                <ShieldCheck className="h-6 w-6 text-primary" />
              </div>
              <h3 className="mb-2 text-lg font-semibold">Secure Payment</h3>
              <p className="text-sm text-muted-foreground">
                Accept payments via Zelle and Bitcoin for your convenience and security.
              </p>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t bg-background py-8">
        <div className="container text-center text-sm text-muted-foreground">
          <p>© 2025 {APP_TITLE}. All rights reserved.</p>
          <p className="mt-2">For research purposes only. Not for human consumption.</p>
        </div>
      </footer>
    </div>
  );
}
