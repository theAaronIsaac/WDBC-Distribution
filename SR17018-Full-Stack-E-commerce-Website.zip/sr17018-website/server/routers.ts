import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { z } from "zod";
import { authenticateUser, createAdminUser, changePassword } from "./auth";
import { SignJWT } from "jose";
import { ENV } from "./_core/env";
import { 
  getAllProducts, 
  getProductById,
  createOrder,
  createOrderItem,
  getOrderByOrderNumber,
  getOrderItems,
  getActiveShippingRates,
  getAllOrders,
  updateOrderStatus,
  updateOrderPaymentStatus,
  getAllShippingRates
} from "./db";
import { TRPCError } from "@trpc/server";

// Generate unique order number
function generateOrderNumber(): string {
  const timestamp = Date.now().toString(36).toUpperCase();
  const random = Math.random().toString(36).substring(2, 8).toUpperCase();
  return `SR${timestamp}${random}`;
}

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    
    login: publicProcedure
      .input(z.object({
        email: z.string().email(),
        password: z.string().min(6),
      }))
      .mutation(async ({ input, ctx }) => {
        const result = await authenticateUser(input.email, input.password);
        
        if (!result.success || !result.user) {
          throw new TRPCError({
            code: "UNAUTHORIZED",
            message: result.error || "Invalid credentials",
          });
        }

        // Create JWT token
        const secret = new TextEncoder().encode(process.env.JWT_SECRET || "fallback-secret");
        const token = await new SignJWT({
          userId: result.user.id,
          openId: result.user.openId,
          email: result.user.email,
          role: result.user.role,
        })
          .setProtectedHeader({ alg: "HS256" })
          .setExpirationTime("7d")
          .sign(secret);

        // Set cookie
        const cookieOptions = getSessionCookieOptions(ctx.req);
        ctx.res.cookie(COOKIE_NAME, token, {
          ...cookieOptions,
          maxAge: 7 * 24 * 60 * 60 * 1000, // 7 days
        });

        return {
          success: true,
          user: {
            id: result.user.id,
            email: result.user.email,
            name: result.user.name,
            role: result.user.role,
          },
        };
      }),

    register: publicProcedure
      .input(z.object({
        email: z.string().email(),
        password: z.string().min(6),
        name: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        const result = await createAdminUser(input.email, input.password, input.name);
        
        if (!result.success) {
          throw new TRPCError({
            code: "BAD_REQUEST",
            message: result.error || "Failed to create account",
          });
        }

        return {
          success: true,
          message: "Admin account created successfully",
        };
      }),

    changePassword: protectedProcedure
      .input(z.object({
        currentPassword: z.string(),
        newPassword: z.string().min(6),
      }))
      .mutation(async ({ input, ctx }) => {
        const result = await changePassword(
          ctx.user.id,
          input.currentPassword,
          input.newPassword
        );
        
        if (!result.success) {
          throw new TRPCError({
            code: "BAD_REQUEST",
            message: result.error || "Failed to change password",
          });
        }

        return {
          success: true,
          message: "Password changed successfully",
        };
      }),
    
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  products: router({
    list: publicProcedure.query(async () => {
      return await getAllProducts();
    }),
    
    getById: publicProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        const product = await getProductById(input.id);
        if (!product) {
          throw new TRPCError({ code: "NOT_FOUND", message: "Product not found" });
        }
        return product;
      }),
  }),

  shipping: router({
    getRates: publicProcedure.query(async () => {
      return await getActiveShippingRates();
    }),
    
    getAllRates: protectedProcedure.query(async ({ ctx }) => {
      if (ctx.user.role !== 'admin') {
        throw new TRPCError({ code: "FORBIDDEN", message: "Admin access required" });
      }
      return await getAllShippingRates();
    }),
  }),

  orders: router({
    create: publicProcedure
      .input(z.object({
        customerName: z.string().min(1),
        customerEmail: z.string().email(),
        customerPhone: z.string().optional(),
        shippingAddress: z.string().min(1),
        shippingCity: z.string().min(1),
        shippingState: z.string().min(1),
        shippingZip: z.string().min(1),
        shippingCountry: z.string().default("USA"),
        shippingCarrier: z.string(),
        shippingService: z.string(),
        shippingCost: z.number(),
        paymentMethod: z.enum(["zelle", "btc"]),
        subtotal: z.number(),
        total: z.number(),
        customerNotes: z.string().optional(),
        items: z.array(z.object({
          productId: z.number(),
          quantity: z.number().min(1),
          pricePerUnit: z.number(),
        })),
      }))
      .mutation(async ({ input }) => {
        const orderNumber = generateOrderNumber();
        
        // Create the order
        const order = await createOrder({
          orderNumber,
          customerName: input.customerName,
          customerEmail: input.customerEmail,
          customerPhone: input.customerPhone || null,
          shippingAddress: input.shippingAddress,
          shippingCity: input.shippingCity,
          shippingState: input.shippingState,
          shippingZip: input.shippingZip,
          shippingCountry: input.shippingCountry,
          shippingCarrier: input.shippingCarrier,
          shippingService: input.shippingService,
          shippingCost: input.shippingCost,
          paymentMethod: input.paymentMethod,
          subtotal: input.subtotal,
          total: input.total,
          customerNotes: input.customerNotes || null,
        });

        // Create order items
        for (const item of input.items) {
          await createOrderItem({
            orderId: order.id,
            productId: item.productId,
            quantity: item.quantity,
            pricePerUnit: item.pricePerUnit,
          });
        }

        return { order, orderNumber };
      }),

    getByOrderNumber: publicProcedure
      .input(z.object({ orderNumber: z.string() }))
      .query(async ({ input }) => {
        const order = await getOrderByOrderNumber(input.orderNumber);
        if (!order) {
          throw new TRPCError({ code: "NOT_FOUND", message: "Order not found" });
        }
        const items = await getOrderItems(order.id);
        return { order, items };
      }),

    // Admin procedures
    list: protectedProcedure.query(async ({ ctx }) => {
      if (ctx.user.role !== 'admin') {
        throw new TRPCError({ code: "FORBIDDEN", message: "Admin access required" });
      }
      return await getAllOrders();
    }),

    updateStatus: protectedProcedure
      .input(z.object({
        orderId: z.number(),
        status: z.enum(["pending", "processing", "shipped", "delivered", "cancelled"]),
        trackingNumber: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        if (ctx.user.role !== 'admin') {
          throw new TRPCError({ code: "FORBIDDEN", message: "Admin access required" });
        }
        await updateOrderStatus(input.orderId, input.status, input.trackingNumber);
        return { success: true };
      }),

    updatePaymentStatus: protectedProcedure
      .input(z.object({
        orderId: z.number(),
        paymentStatus: z.enum(["pending", "completed", "failed"]),
      }))
      .mutation(async ({ ctx, input }) => {
        if (ctx.user.role !== 'admin') {
          throw new TRPCError({ code: "FORBIDDEN", message: "Admin access required" });
        }
        await updateOrderPaymentStatus(input.orderId, input.paymentStatus);
        return { success: true };
      }),
  }),
});

export type AppRouter = typeof appRouter;
