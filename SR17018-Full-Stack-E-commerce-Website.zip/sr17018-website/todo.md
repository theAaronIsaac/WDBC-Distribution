# Project TODO

## Database & Backend
- [x] Create products table with weight options (1g, 3g, 5g, 10g)
- [x] Create orders table with customer info and order details
- [x] Create order items table for cart items
- [x] Create shipping rates table for UPS/USPS options
- [x] Add tRPC procedures for product listing
- [x] Add tRPC procedures for cart management
- [x] Add tRPC procedures for order creation
- [x] Add tRPC procedures for shipping rate calculation
- [x] Add admin procedures for order management

## Frontend - Public Pages
- [x] Design attractive landing page with research disclaimer
- [x] Create product catalog page showing SR17018 in different weights
- [x] Implement shopping cart functionality
- [x] Build checkout page with customer information form
- [x] Add payment method selection (Zelle/BTC)
- [x] Implement shipping method selection (UPS/USPS options)
- [x] Create order confirmation page
- [x] Add "For Research Purposes Only" disclaimer throughout site

## Frontend - Admin Panel
- [x] Create admin dashboard for order management
- [x] Build order list view with status filters
- [x] Add order detail view
- [x] Implement order status update functionality

## Testing & Deployment
- [x] Write vitest tests for critical procedures
- [x] Test checkout flow end-to-end
- [x] Create checkpoint for deployment

## Pricing and Shipping Updates
- [x] Update product prices: 1g=$60, 3g=$180, 5g=$290, 10g=$490
- [x] Implement free UPS 2nd Day Air shipping for 3g, 5g, and 10g orders
- [x] Update checkout logic to apply free shipping automatically
- [x] Update tests to reflect new pricing

## Railway Deployment Preparation
- [x] Create railway.json configuration file
- [x] Create .railwayignore file
- [x] Update package.json with Railway build scripts
- [x] Create deployment guide document
- [x] Create environment variables template
- [x] Package all files for download

## Replace Manus OAuth with Email/Password Auth
- [x] Add password field to users table schema
- [x] Install bcrypt for password hashing
- [x] Create authentication procedures (login, register)
- [x] Create admin login page
- [x] Update admin dashboard to use new auth
- [x] Create admin setup script
- [x] Remove Manus OAuth dependencies
- [x] Update deployment guide with new auth setup
- [x] Test login/logout flow
