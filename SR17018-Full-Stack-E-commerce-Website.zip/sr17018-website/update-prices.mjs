import { drizzle } from "drizzle-orm/mysql2";
import { products } from "./drizzle/schema.js";
import { eq } from "drizzle-orm";

const db = drizzle(process.env.DATABASE_URL);

async function updatePrices() {
  console.log("Updating product prices...");

  // 1g = $60.00 (6000 cents)
  await db.update(products)
    .set({ priceUsd: 6000 })
    .where(eq(products.weightGrams, 1));

  // 3g = $180.00 (18000 cents)
  await db.update(products)
    .set({ priceUsd: 18000 })
    .where(eq(products.weightGrams, 3));

  // 5g = $58/g = $290.00 (29000 cents)
  await db.update(products)
    .set({ priceUsd: 29000 })
    .where(eq(products.weightGrams, 5));

  // 10g = $49/g = $490.00 (49000 cents)
  await db.update(products)
    .set({ priceUsd: 49000 })
    .where(eq(products.weightGrams, 10));

  console.log("Prices updated successfully!");
  process.exit(0);
}

updatePrices().catch((error) => {
  console.error("Error updating prices:", error);
  process.exit(1);
});
