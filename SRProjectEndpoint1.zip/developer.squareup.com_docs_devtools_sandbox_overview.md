
**URL:** https://developer.squareup.com/docs/devtools/sandbox/overview

---

Search developer resources
/
Docs & Tools
SDKs
Support
Partnerships
Sign In
Docs Home
Dev Essentials
Payments
Commerce
Customers
Staff
Merchants
Publish
Release notes
Get Started
Create an Account and App
Make your First API Call
View the API Logs
Verify the Payment
What's Next
Overview
Build Basics
Versioning
Access Tokens
Frontend and Backend Development
General Development Concepts
TLS and HTTPS
Using the REST API
Handling Errors
Collecting Information
Language Preferences
Common Data Types
Working with Dates
Working with Monetary Amounts
Working with Addresses
Common Square API Patterns
Custom Attributes
Idempotency
Pagination
Optimistic Concurrency
Clear Object Fields
Square eCommerce APIs
Square API Lifecycle
Developer Tools
Developer Console
Square Dashboard
Sandbox
Test in Sandbox
Sandbox Payments
API Explorer
API Logs
Webhook Event Logs
Webhooks
Create a Notification URL
Subscribe to Event Notifications
Verify and Validate an Event Notification
Manage Operations
Move Event Notifications to Production
Webhook Events Reference
Troubleshooting
Build a Developer Team
Authentication
Postman
MCP Server
Square SDKs
Java
Quickstart
Common API Patterns
Migration Guide
.NET
Quickstart
Common API Patterns
Migration Guide
Node.js
Quickstart
Common API Patterns
Migration Guide
PHP
Quickstart
Common API Patterns
Migration Guide
Python
Quickstart
Common API Patterns
Migration Guide
Ruby
Quickstart
Common API Patterns
Migration Guide
Go
Quickstart
Sample Applications