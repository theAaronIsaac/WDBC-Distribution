        shippingCost: z.number(),
        paymentMethod: z.enum(["square", "btc"]),
        subtotal: z.number(),
        total: z.number(),
        customerNotes: z.string().optional(),
        items: z.array(z.object({
          productId: z.number(),
          quantity: z.number().min(1),
          pricePerUnit: z.number(),
        })),
      }))
      .mutation(async ({ input }) => {
        // Check stock availability for all items before creating order
        for (const item of input.items) {
          const stockCheck = await checkStockAvailability(item.productId, item.quantity);
          if (!stockCheck.available) {
            throw new TRPCError({
              code: "BAD_REQUEST",
              message: `Insufficient stock for product ID ${item.productId}. Available: ${stockCheck.currentStock}, Requested: ${item.quantity}`,
            });
          }
        }

        const orderNumber = generateOrderNumber();
        
        // Create the order
        const order = await createOrder({
          orderNumber,
          customerName: input.customerName,
          customerEmail: input.customerEmail,