
/**
 * Core user table backing auth flow.
 */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  password: varchar("password", { length: 255 }), // Hashed password for email/password auth
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Products table - SR17018 in different weight options
 */
export const products = mysqlTable("products", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  description: text("description"),
  category: mysqlEnum("category", ["chemicals", "labware", "consumables", "clearance"]).default("chemicals").notNull(),
  productType: varchar("productType", { length: 100 }), // e.g., "beaker", "pipette_tips", "paper", "flask"
  weightGrams: int("weightGrams"), // Optional - for chemicals
  priceUsd: int("priceUsd").notNull(), // Store price in cents to avoid decimal issues
  quantityPerUnit: int("quantityPerUnit").default(1), // e.g., 500/box, 1400/case
  unit: varchar("unit", { length: 50 }).default("each"), // e.g., "box", "case", "each"
  imageUrl: text("imageUrl"),
  inStock: boolean("inStock").default(true).notNull(),
  stockQuantity: int("stockQuantity").default(0).notNull(), // Current stock level
  lowStockThreshold: int("lowStockThreshold").default(10).notNull(), // Alert when stock falls below this
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Product = typeof products.$inferSelect;
export type InsertProduct = typeof products.$inferInsert;

/**
 * Orders table - customer orders
 */
export const orders = mysqlTable("orders", {
  id: int("id").autoincrement().primaryKey(),