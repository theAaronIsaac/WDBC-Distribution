import { drizzle } from 'drizzle-orm/mysql2';
import mysql from 'mysql2/promise';
import { products } from './drizzle/schema.js';

const connection = await mysql.createConnection(process.env.DATABASE_URL);
const db = drizzle(connection);

const labWareProducts = [
  {
    name: '250ml Berzelius Beaker',
    description: 'High-quality borosilicate glass beaker with spout for easy pouring. Heat resistant and chemically inert.',
    category: 'lab_ware',
    pricePerUnit: 1200,
    stock: 50,
    weight: null
  },
  {
    name: '500ml Berzelius Beaker',
    description: 'Professional-grade borosilicate glass beaker. Ideal for mixing, heating, and general laboratory use.',
    category: 'lab_ware',
    pricePerUnit: 1800,
    stock: 40,
    weight: null
  },
  {
    name: '1000ml Berzelius Beaker',
    description: 'Large capacity borosilicate glass beaker for high-volume laboratory applications.',
    category: 'lab_ware',
    pricePerUnit: 2500,
    stock: 30,
    weight: null
  },
  {
    name: '250ml Erlenmeyer Flask',
    description: 'Conical flask with narrow neck, perfect for mixing and swirling solutions without spillage.',
    category: 'lab_ware',
    pricePerUnit: 1500,
    stock: 45,
    weight: null
  },
  {
    name: '500ml Erlenmeyer Flask',
    description: 'Medium capacity Erlenmeyer flask made from durable borosilicate glass.',
    category: 'lab_ware',
    pricePerUnit: 2200,
    stock: 35,
    weight: null
  },
  {
    name: '1000ml Erlenmeyer Flask',
    description: 'Large Erlenmeyer flask for high-volume mixing and storage applications.',
    category: 'lab_ware',
    pricePerUnit: 3000,
    stock: 25,
    weight: null
  },
  {
    name: '100ml Volumetric Flask',
    description: 'Precision volumetric flask with single graduation mark for accurate solution preparation.',
    category: 'lab_ware',
    pricePerUnit: 2800,
    stock: 20,
    weight: null
  },
  {
    name: '1ml Graduated Pipette',
    description: 'Precision glass pipette with 0.01ml graduations for accurate liquid transfer.',
    category: 'lab_ware',
    pricePerUnit: 800,
    stock: 60,
    weight: null
  },
  {
    name: '10ml Graduated Pipette',
    description: 'Standard laboratory pipette with 0.1ml graduations. Essential for volumetric work.',
    category: 'lab_ware',
    pricePerUnit: 1200,
    stock: 55,
    weight: null
  },
  {
    name: '25ml Graduated Pipette',
    description: 'Large capacity graduated pipette for transferring larger volumes with precision.',
    category: 'lab_ware',
    pricePerUnit: 1600,
    stock: 40,
    weight: null
  }
];

console.log('Adding lab ware products to database...');

for (const product of labWareProducts) {
  await db.insert(products).values(product);
  console.log(`Added: ${product.name}`);
}

console.log('Lab ware products added successfully!');
await connection.end();
