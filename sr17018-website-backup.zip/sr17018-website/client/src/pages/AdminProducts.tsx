import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { trpc } from "@/lib/trpc";
import { Microscope, Loader2, Upload, Image as ImageIcon } from "lucide-react";
import { useState } from "react";
import { Link, useLocation } from "wouter";
import { APP_TITLE } from "@/const";
import Footer from "@/components/Footer";
import { toast } from "sonner";


export default function AdminProducts() {
  const { user, loading, isAuthenticated } = useAuth();
  const [, setLocation] = useLocation();
  const [selectedProduct, setSelectedProduct] = useState<number | null>(null);
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [uploading, setUploading] = useState(false);
  const [stockDialogOpen, setStockDialogOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<any>(null);
  const [stockQuantity, setStockQuantity] = useState("");
  const [lowStockThreshold, setLowStockThreshold] = useState("");

  const { data: products, isLoading, refetch } = trpc.products.list.useQuery(undefined, {
    enabled: isAuthenticated && user?.role === "admin",
  });

  const updateImage = trpc.products.updateImage.useMutation({
    onSuccess: () => {
      toast.success("Product image updated");
      refetch();
      setSelectedProduct(null);
      setImageFile(null);
    },
    onError: (error) => {
      toast.error(error.message || "Failed to update image");
    },
  });

  const updateStock = trpc.inventory.updateStock.useMutation({
    onSuccess: () => {
      toast.success("Stock updated successfully");
      refetch();
      setStockDialogOpen(false);
    },
    onError: (error) => {
      toast.error(error.message || "Failed to update stock");
    },
  });

  const updateThreshold = trpc.inventory.updateThreshold.useMutation({
    onSuccess: () => {
      toast.success("Threshold updated successfully");
      refetch();
    },
    onError: (error) => {
      toast.error(error.message || "Failed to update threshold");
    },
  });

  const handleImageUpload = async () => {
    if (!imageFile || !selectedProduct) return;

    setUploading(true);
    try {
      // Read file as buffer
      const arrayBuffer = await imageFile.arrayBuffer();
      const buffer = new Uint8Array(arrayBuffer);

      // Upload to S3 via trpc
      const randomSuffix = Math.random().toString(36).substring(2, 10);
      const fileKey = `products/${selectedProduct}-${randomSuffix}.${imageFile.name.split('.').pop()}`;
      const uploadMutation = trpc.storage.upload.useMutation();
      const { url } = await uploadMutation.mutateAsync({
        key: fileKey,
        data: Array.from(buffer),
        contentType: imageFile.type,
      });

      // Update product with image URL
      await updateImage.mutateAsync({
        productId: selectedProduct,
        imageUrl: url,
      });
    } catch (error) {
      toast.error("Failed to upload image");
      console.error(error);
    } finally {
      setUploading(false);
    }
  };

  const formatPrice = (cents: number) => {
    return `$${(cents / 100).toFixed(2)}`;
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!isAuthenticated) {
    if (typeof window !== "undefined") {
      setLocation("/login");
    }
    return null;
  }

  if (user?.role !== "admin") {
    return (
      <div className="min-h-screen bg-gradient-to-b from-background to-secondary">
        <header className="border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
          <div className="container flex h-16 items-center justify-between">
            <Link href="/">
              <div className="flex items-center gap-2 cursor-pointer">
                <Microscope className="h-6 w-6 text-white" />
                <h1 className="text-xl font-bold">{APP_TITLE}</h1>
              </div>
            </Link>
          </div>
        </header>
        <div className="container py-12">
          <Card className="text-center py-12">
            <CardContent>
              <h3 className="text-xl font-semibold mb-2">Access Denied</h3>
              <p className="text-muted-foreground mb-6">
                You do not have permission to access the admin dashboard
              </p>
              <Link href="/">
                <Button>Go Home</Button>
              </Link>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-secondary">
      {/* Header */}
      <header className="border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center justify-between">
          <Link href="/">
            <div className="flex items-center gap-2 cursor-pointer">
              <Microscope className="h-6 w-6 text-white" />
              <h1 className="text-xl font-bold">{APP_TITLE}</h1>
            </div>
          </Link>
          <nav className="flex items-center gap-4">
            <Link href="/admin">
              <Button variant="ghost">Orders</Button>
            </Link>
            <span className="text-sm text-muted-foreground">
              Admin: {user?.name || user?.email}
            </span>
          </nav>
        </div>
      </header>

      {/* Product Management */}
      <section className="container py-12">
        <div className="mb-8">
          <h2 className="text-3xl font-bold mb-2">Product Management</h2>
          <p className="text-muted-foreground">
            Upload and manage product images
          </p>
        </div>

        {isLoading ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        ) : products && products.length > 0 ? (
          <Card>
            <CardHeader>
              <CardTitle>All Products</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Image</TableHead>
                      <TableHead>Name</TableHead>
                      <TableHead>Category</TableHead>
                      <TableHead>Price</TableHead>
                      <TableHead>Stock</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {products.map((product) => (
                      <TableRow key={product.id}>
                        <TableCell>
                          {product.imageUrl ? (
                            <img
                              src={product.imageUrl}
                              alt={product.name}
                              className="h-12 w-12 object-cover rounded"
                            />
                          ) : (
                            <div className="h-12 w-12 bg-muted rounded flex items-center justify-center">
                              <ImageIcon className="h-6 w-6 text-muted-foreground" />
                            </div>
                          )}
                        </TableCell>
                        <TableCell className="font-medium">{product.name}</TableCell>
                        <TableCell className="capitalize">{product.category}</TableCell>
                        <TableCell className="font-semibold">
                          {formatPrice(product.priceUsd)}
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <span className={product.stockQuantity <= product.lowStockThreshold ? "text-red-600 font-semibold" : ""}>
                              {product.stockQuantity}
                            </span>
                            {product.stockQuantity <= product.lowStockThreshold && (
                              <span className="text-xs bg-red-100 text-red-700 px-2 py-0.5 rounded">Low</span>
                            )}
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex gap-2">
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => setSelectedProduct(product.id)}
                            >
                              <Upload className="h-4 w-4 mr-2" />
                              Image
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => {
                                setEditingProduct(product);
                                setStockQuantity(product.stockQuantity.toString());
                                setLowStockThreshold(product.lowStockThreshold.toString());
                                setStockDialogOpen(true);
                              }}
                            >
                              Stock
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        ) : (
          <Card className="text-center py-12">
            <CardContent>
              <h3 className="text-xl font-semibold mb-2">No products found</h3>
              <p className="text-muted-foreground">
                Products will appear here once they are added to the database
              </p>
            </CardContent>
          </Card>
        )}
      </section>

      {/* Image Upload Dialog */}
      <Dialog open={selectedProduct !== null} onOpenChange={() => setSelectedProduct(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Upload Product Image</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="image">Select Image</Label>
              <Input
                id="image"
                type="file"
                accept="image/*"
                onChange={(e) => setImageFile(e.target.files?.[0] || null)}
              />
              {imageFile && (
                <p className="text-sm text-muted-foreground">
                  Selected: {imageFile.name}
                </p>
              )}
            </div>
            <div className="flex gap-2">
              <Button
                onClick={handleImageUpload}
                disabled={!imageFile || uploading}
              >
                {uploading ? (
                  <>
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                    Uploading...
                  </>
                ) : (
                  "Upload Image"
                )}
              </Button>
              <Button variant="outline" onClick={() => setSelectedProduct(null)}>
                Cancel
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Stock Management Dialog */}
      <Dialog open={stockDialogOpen} onOpenChange={setStockDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Manage Stock - {editingProduct?.name}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="stockQuantity">Stock Quantity</Label>
              <Input
                id="stockQuantity"
                type="number"
                min="0"
                value={stockQuantity}
                onChange={(e) => setStockQuantity(e.target.value)}
                placeholder="Enter stock quantity"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="lowStockThreshold">Low Stock Alert Threshold</Label>
              <Input
                id="lowStockThreshold"
                type="number"
                min="0"
                value={lowStockThreshold}
                onChange={(e) => setLowStockThreshold(e.target.value)}
                placeholder="Enter threshold"
              />
              <p className="text-sm text-muted-foreground">
                You'll be alerted when stock falls below this number
              </p>
            </div>
            <div className="flex gap-2">
              <Button
                onClick={() => {
                  if (editingProduct) {
                    updateStock.mutate({
                      productId: editingProduct.id,
                      stockQuantity: parseInt(stockQuantity),
                    });
                    updateThreshold.mutate({
                      productId: editingProduct.id,
                      lowStockThreshold: parseInt(lowStockThreshold),
                    });
                  }
                }}
                disabled={updateStock.isPending || updateThreshold.isPending}
              >
                {updateStock.isPending || updateThreshold.isPending ? (
                  <>
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                    Saving...
                  </>
                ) : (
                  "Save Changes"
                )}
              </Button>
              <Button variant="outline" onClick={() => setStockDialogOpen(false)}>
                Cancel
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Footer */}
      <Footer />
    </div>
  );
}
