ALTER TABLE `products` MODIFY COLUMN `weightGrams` int;--> statement-breakpoint
ALTER TABLE `products` ADD `category` enum('chemicals','labware','consumables','clearance') DEFAULT 'chemicals' NOT NULL;--> statement-breakpoint
ALTER TABLE `products` ADD `quantityPerUnit` int DEFAULT 1;--> statement-breakpoint
ALTER TABLE `products` ADD `unit` varchar(50) DEFAULT 'each';