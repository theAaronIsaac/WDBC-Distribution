CREATE TABLE `abandonedCarts` (
	`id` int AUTO_INCREMENT NOT NULL,
	`customerEmail` varchar(320) NOT NULL,
	`customerName` varchar(255),
	`cartData` text NOT NULL,
	`totalAmount` int NOT NULL,
	`recoveryEmailSent` boolean NOT NULL DEFAULT false,
	`recoveryEmailSentAt` timestamp,
	`converted` boolean NOT NULL DEFAULT false,
	`convertedOrderNumber` varchar(64),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `abandonedCarts_id` PRIMARY KEY(`id`)
);
