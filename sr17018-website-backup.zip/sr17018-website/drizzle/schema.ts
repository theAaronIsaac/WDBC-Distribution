import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, decimal, boolean } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  password: varchar("password", { length: 255 }), // Hashed password for email/password auth
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Products table - SR17018 in different weight options
 */
export const products = mysqlTable("products", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  description: text("description"),
  category: mysqlEnum("category", ["chemicals", "labware", "consumables", "clearance"]).default("chemicals").notNull(),
  productType: varchar("productType", { length: 100 }), // e.g., "beaker", "pipette_tips", "paper", "flask"
  weightGrams: int("weightGrams"), // Optional - for chemicals
  priceUsd: int("priceUsd").notNull(), // Store price in cents to avoid decimal issues
  quantityPerUnit: int("quantityPerUnit").default(1), // e.g., 500/box, 1400/case
  unit: varchar("unit", { length: 50 }).default("each"), // e.g., "box", "case", "each"
  imageUrl: text("imageUrl"),
  inStock: boolean("inStock").default(true).notNull(),
  stockQuantity: int("stockQuantity").default(0).notNull(), // Current stock level
  lowStockThreshold: int("lowStockThreshold").default(10).notNull(), // Alert when stock falls below this
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Product = typeof products.$inferSelect;
export type InsertProduct = typeof products.$inferInsert;

/**
 * Orders table - customer orders
 */
export const orders = mysqlTable("orders", {
  id: int("id").autoincrement().primaryKey(),
  orderNumber: varchar("orderNumber", { length: 64 }).notNull().unique(),
  
  // Customer information
  customerName: varchar("customerName", { length: 255 }).notNull(),
  customerEmail: varchar("customerEmail", { length: 320 }).notNull(),
  customerPhone: varchar("customerPhone", { length: 50 }),
  
  // Shipping address
  shippingAddress: text("shippingAddress").notNull(),
  shippingCity: varchar("shippingCity", { length: 255 }).notNull(),
  shippingState: varchar("shippingState", { length: 100 }).notNull(),
  shippingZip: varchar("shippingZip", { length: 20 }).notNull(),
  shippingCountry: varchar("shippingCountry", { length: 100 }).notNull().default("USA"),
  
  // Shipping method
  shippingCarrier: varchar("shippingCarrier", { length: 50 }).notNull(), // UPS or USPS
  shippingService: varchar("shippingService", { length: 100 }).notNull(), // e.g., "Ground", "Priority Mail"
  shippingCost: int("shippingCost").notNull(), // in cents
  
  // Payment
  paymentMethod: mysqlEnum("paymentMethod", ["square", "btc"]).notNull(),
  paymentStatus: mysqlEnum("paymentStatus", ["pending", "completed", "failed"]).default("pending").notNull(),
  
  // Order totals
  subtotal: int("subtotal").notNull(), // in cents
  total: int("total").notNull(), // in cents (subtotal + shipping)
  
  // Order status
  status: mysqlEnum("status", ["pending", "processing", "shipped", "delivered", "cancelled"]).default("pending").notNull(),
  trackingNumber: varchar("trackingNumber", { length: 255 }),
  
  // Notes
  customerNotes: text("customerNotes"),
  adminNotes: text("adminNotes"),
  
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Order = typeof orders.$inferSelect;
export type InsertOrder = typeof orders.$inferInsert;

/**
 * Order items table - items in each order
 */
export const orderItems = mysqlTable("orderItems", {
  id: int("id").autoincrement().primaryKey(),
  orderId: int("orderId").notNull(),
  productId: int("productId").notNull(),
  quantity: int("quantity").notNull(),
  pricePerUnit: int("pricePerUnit").notNull(), // in cents, snapshot at time of order
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type OrderItem = typeof orderItems.$inferSelect;
export type InsertOrderItem = typeof orderItems.$inferInsert;

/**
 * Shipping rates table - predefined shipping options
 */
export const shippingRates = mysqlTable("shippingRates", {
  id: int("id").autoincrement().primaryKey(),
  carrier: varchar("carrier", { length: 50 }).notNull(), // UPS or USPS
  serviceName: varchar("serviceName", { length: 100 }).notNull(),
  description: text("description"),
  estimatedDays: varchar("estimatedDays", { length: 50 }), // e.g., "1-3 business days"
  baseRate: int("baseRate").notNull(), // in cents
  active: boolean("active").default(true).notNull(),
  displayOrder: int("displayOrder").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type ShippingRate = typeof shippingRates.$inferSelect;
export type InsertShippingRate = typeof shippingRates.$inferInsert;

/**
 * Contact form submissions table
 */
export const contactSubmissions = mysqlTable("contactSubmissions", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  email: varchar("email", { length: 320 }).notNull(),
  phone: varchar("phone", { length: 50 }),
  subject: varchar("subject", { length: 255 }).notNull(),
  message: text("message").notNull(),
  status: mysqlEnum("status", ["new", "read", "replied"]).default("new").notNull(),
  adminNotes: text("adminNotes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type ContactSubmission = typeof contactSubmissions.$inferSelect;
export type InsertContactSubmission = typeof contactSubmissions.$inferInsert;

/**
 * Abandoned carts table - track incomplete checkouts for recovery emails
 */
export const abandonedCarts = mysqlTable("abandonedCarts", {
  id: int("id").autoincrement().primaryKey(),
  customerEmail: varchar("customerEmail", { length: 320 }).notNull(),
  customerName: varchar("customerName", { length: 255 }),
  cartData: text("cartData").notNull(), // JSON string of cart items
  totalAmount: int("totalAmount").notNull(), // in cents
  recoveryEmailSent: boolean("recoveryEmailSent").default(false).notNull(),
  recoveryEmailSentAt: timestamp("recoveryEmailSentAt"),
  converted: boolean("converted").default(false).notNull(), // true if they completed purchase
  convertedOrderNumber: varchar("convertedOrderNumber", { length: 64 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type AbandonedCart = typeof abandonedCarts.$inferSelect;
export type InsertAbandonedCart = typeof abandonedCarts.$inferInsert;

/**
 * Recently viewed items - tracks product views for personalized recommendations
 */
export const recentlyViewedItems = mysqlTable("recently_viewed_items", {
  id: int("id").autoincrement().primaryKey(),
  sessionId: varchar("sessionId", { length: 255 }).notNull(), // Browser session ID or user ID
  productId: int("productId").notNull(),
  viewedAt: timestamp("viewedAt").defaultNow().notNull(),
});

export type RecentlyViewedItem = typeof recentlyViewedItems.$inferSelect;
export type InsertRecentlyViewedItem = typeof recentlyViewedItems.$inferInsert;
