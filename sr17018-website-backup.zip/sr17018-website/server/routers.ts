import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { z } from "zod";
import { authenticateUser, createAdminUser, changePassword } from "./auth";
import { SignJWT } from "jose";
import { ENV } from "./_core/env";
import { 
  getAllProducts, 
  getProductById,
  createOrder,
  createOrderItem,
  getOrderByOrderNumber,
  getOrderItems,
  getActiveShippingRates,
  getAllOrders,
  updateOrderStatus,
  updateOrderPaymentStatus,
  getAllShippingRates
} from "./db";
import { TRPCError } from "@trpc/server";
import { createSquarePayment } from "./square-payment";
import { sendOrderConfirmationEmail } from "./email-notification";
import { markCartAsConverted, upsertAbandonedCart } from "./abandoned-cart-db";
import { abandonedCartRouter } from "./abandoned-cart-router";
import { decrementStock, checkStockAvailability } from "./inventory-db";
import { inventoryRouter } from "./inventory-router";
import { getFilteredOrders } from "./order-filtering-db";
import { recordProductView, getRecentlyViewedItems } from "./recently-viewed-db";

// Generate unique order number
function generateOrderNumber(): string {
  const timestamp = Date.now().toString(36).toUpperCase();
  const random = Math.random().toString(36).substring(2, 8).toUpperCase();
  return `SR${timestamp}${random}`;
}

export const appRouter = router({
  system: systemRouter,
  abandonedCart: abandonedCartRouter,
  inventory: inventoryRouter,
  recentlyViewed: router({
    record: publicProcedure
      .input(z.object({
        sessionId: z.string(),
        productId: z.number(),
      }))
      .mutation(async ({ input }) => {
        await recordProductView(input.sessionId, input.productId);
        return { success: true };
      }),
    
    getItems: publicProcedure
      .input(z.object({
        sessionId: z.string(),
      }))
      .query(async ({ input }) => {
        return await getRecentlyViewedItems(input.sessionId);
      }),
  }),
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    
    login: publicProcedure
      .input(z.object({
        email: z.string().email(),
        password: z.string().min(6),
      }))
      .mutation(async ({ input, ctx }) => {
        const result = await authenticateUser(input.email, input.password);
        
        if (!result.success || !result.user) {
          throw new TRPCError({
            code: "UNAUTHORIZED",
            message: result.error || "Invalid credentials",
          });
        }

        // Create JWT token
        const secret = new TextEncoder().encode(process.env.JWT_SECRET || "fallback-secret");
        const token = await new SignJWT({
          userId: result.user.id,
          openId: result.user.openId,
          email: result.user.email,
          role: result.user.role,
        })
          .setProtectedHeader({ alg: "HS256" })
          .setExpirationTime("7d")
          .sign(secret);

        // Set cookie
        const cookieOptions = getSessionCookieOptions(ctx.req);
        ctx.res.cookie(COOKIE_NAME, token, {
          ...cookieOptions,
          maxAge: 7 * 24 * 60 * 60 * 1000, // 7 days
        });

        return {
          success: true,
          user: {
            id: result.user.id,
            email: result.user.email,
            name: result.user.name,
            role: result.user.role,
          },
        };
      }),

    register: publicProcedure
      .input(z.object({
        email: z.string().email(),
        password: z.string().min(6),
        name: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        const result = await createAdminUser(input.email, input.password, input.name);
        
        if (!result.success) {
          throw new TRPCError({
            code: "BAD_REQUEST",
            message: result.error || "Failed to create account",
          });
        }

        return {
          success: true,
          message: "Admin account created successfully",
        };
      }),

    changePassword: protectedProcedure
      .input(z.object({
        currentPassword: z.string(),
        newPassword: z.string().min(6),
      }))
      .mutation(async ({ input, ctx }) => {
        const result = await changePassword(
          ctx.user.id,
          input.currentPassword,
          input.newPassword
        );
        
        if (!result.success) {
          throw new TRPCError({
            code: "BAD_REQUEST",
            message: result.error || "Failed to change password",
          });
        }

        return {
          success: true,
          message: "Password changed successfully",
        };
      }),
    
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  products: router({
    list: publicProcedure.query(async () => {
      return await getAllProducts();
    }),
    
    getById: publicProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        const product = await getProductById(input.id);
        if (!product) {
          throw new TRPCError({ code: "NOT_FOUND", message: "Product not found" });
        }
        return product;
      }),
    
    updateImage: protectedProcedure
      .input(z.object({
        productId: z.number(),
        imageUrl: z.string().url(),
      }))
      .mutation(async ({ input, ctx }) => {
        if (ctx.user.role !== 'admin') {
          throw new TRPCError({ code: "FORBIDDEN", message: "Admin access required" });
        }
        
        const { updateProductImage } = await import("./db");
        await updateProductImage(input.productId, input.imageUrl);
        
        return { success: true };
      }),
    
    create: protectedProcedure
      .input(z.object({
        name: z.string().min(1),
        description: z.string().optional(),
        category: z.enum(["chemicals", "labware", "consumables", "clearance"]),
        priceUsd: z.number().min(0),
        weightGrams: z.number().optional(),
        inStock: z.boolean().default(true),
        imageUrl: z.string().url().optional(),
        quantityPerUnit: z.number().optional(),
        unit: z.string().optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        if (ctx.user.role !== 'admin') {
          throw new TRPCError({ code: "FORBIDDEN", message: "Admin access required" });
        }
        
        const { createProduct } = await import("./db");
        const product = await createProduct(input);
        return product;
      }),
    
    update: protectedProcedure
      .input(z.object({
        id: z.number(),
        name: z.string().min(1).optional(),
        description: z.string().optional(),
        category: z.enum(["chemicals", "labware", "consumables", "clearance"]).optional(),
        priceUsd: z.number().min(0).optional(),
        weightGrams: z.number().optional(),
        inStock: z.boolean().optional(),
        imageUrl: z.string().url().optional(),
        quantityPerUnit: z.number().optional(),
        unit: z.string().optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        if (ctx.user.role !== 'admin') {
          throw new TRPCError({ code: "FORBIDDEN", message: "Admin access required" });
        }
        
        const { updateProduct } = await import("./db");
        await updateProduct(input.id, input);
        return { success: true };
      }),
    
    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input, ctx }) => {
        if (ctx.user.role !== 'admin') {
          throw new TRPCError({ code: "FORBIDDEN", message: "Admin access required" });
        }
        
        const { deleteProduct } = await import("./db");
        await deleteProduct(input.id);
        return { success: true };
      }),
  }),

  shipping: router({
    getRates: publicProcedure.query(async () => {
      return await getActiveShippingRates();
    }),
    
    getAllRates: protectedProcedure.query(async ({ ctx }) => {
      if (ctx.user.role !== 'admin') {
        throw new TRPCError({ code: "FORBIDDEN", message: "Admin access required" });
      }
      return await getAllShippingRates();
    }),
  }),

  orders: router({
    create: publicProcedure
      .input(z.object({
        customerName: z.string().min(1),
        customerEmail: z.string().email(),
        customerPhone: z.string().optional(),
        shippingAddress: z.string().min(1),
        shippingCity: z.string().min(1),
        shippingState: z.string().min(1),
        shippingZip: z.string().min(1),
        shippingCountry: z.string().default("USA"),
        shippingCarrier: z.string(),
        shippingService: z.string(),
        shippingCost: z.number(),
        paymentMethod: z.enum(["square", "btc"]),
        subtotal: z.number(),
        total: z.number(),
        customerNotes: z.string().optional(),
        items: z.array(z.object({
          productId: z.number(),
          quantity: z.number().min(1),
          pricePerUnit: z.number(),
        })),
      }))
      .mutation(async ({ input }) => {
        // Check stock availability for all items before creating order
        for (const item of input.items) {
          const stockCheck = await checkStockAvailability(item.productId, item.quantity);
          if (!stockCheck.available) {
            throw new TRPCError({
              code: "BAD_REQUEST",
              message: `Insufficient stock for product ID ${item.productId}. Available: ${stockCheck.currentStock}, Requested: ${item.quantity}`,
            });
          }
        }

        const orderNumber = generateOrderNumber();
        
        // Create the order
        const order = await createOrder({
          orderNumber,
          customerName: input.customerName,
          customerEmail: input.customerEmail,
          customerPhone: input.customerPhone || null,
          shippingAddress: input.shippingAddress,
          shippingCity: input.shippingCity,
          shippingState: input.shippingState,
          shippingZip: input.shippingZip,
          shippingCountry: input.shippingCountry,
          shippingCarrier: input.shippingCarrier,
          shippingService: input.shippingService,
          shippingCost: input.shippingCost,
          paymentMethod: input.paymentMethod,
          subtotal: input.subtotal,
          total: input.total,
          customerNotes: input.customerNotes || null,
        });

        // Create order items and decrement stock
        for (const item of input.items) {
          await createOrderItem({
            orderId: order.id,
            productId: item.productId,
            quantity: item.quantity,
            pricePerUnit: item.pricePerUnit,
          });
          
          // Decrement stock quantity
          await decrementStock(item.productId, item.quantity);
        }

        // Get order items with product names for email
        const orderItems = await getOrderItems(order.id);

        // Mark abandoned cart as converted if exists
        markCartAsConverted(input.customerEmail, orderNumber).catch(error => {
          console.error('Failed to mark cart as converted:', error);
        });

        // Send order confirmation email (non-blocking)
        sendOrderConfirmationEmail({
          orderNumber,
          customerName: input.customerName,
          customerEmail: input.customerEmail,
          items: orderItems.map(item => ({
            productName: item.productName,
            productId: item.productId,
            quantity: item.quantity,
            pricePerUnit: item.pricePerUnit,
          })),
          subtotal: input.subtotal,
          shippingCost: input.shippingCost,
          total: input.total,
          shippingAddress: input.shippingAddress,
          shippingCity: input.shippingCity,
          shippingState: input.shippingState,
          shippingZip: input.shippingZip,
          shippingCountry: input.shippingCountry,
          shippingCarrier: input.shippingCarrier,
          shippingService: input.shippingService,
          paymentMethod: input.paymentMethod,
          paymentStatus: order.paymentStatus,
        }).catch(error => {
          console.error('Failed to send order confirmation email:', error);
          // Don't throw - email failure shouldn't block order creation
        });

        return { order, orderNumber };
      }),

    getByOrderNumber: publicProcedure
      .input(z.object({ orderNumber: z.string() }))
      .query(async ({ input }) => {
        const order = await getOrderByOrderNumber(input.orderNumber);
        if (!order) {
          throw new TRPCError({ code: "NOT_FOUND", message: "Order not found" });
        }
        const items = await getOrderItems(order.id);
        return { order, items };
      }),

    processSquarePayment: publicProcedure
      .input(z.object({
        orderNumber: z.string(),
        sourceId: z.string(), // Payment token from Square Web Payments SDK
        amountCents: z.number(),
      }))
      .mutation(async ({ input }) => {
        // Get order to verify it exists and get customer email
        const order = await getOrderByOrderNumber(input.orderNumber);
        if (!order) {
          throw new TRPCError({ code: "NOT_FOUND", message: "Order not found" });
        }

        // Process payment with Square
        const result = await createSquarePayment({
          sourceId: input.sourceId,
          amountCents: input.amountCents,
          orderNumber: input.orderNumber,
          customerEmail: order.customerEmail,
        });

        if (!result.success) {
          throw new TRPCError({ 
            code: "INTERNAL_SERVER_ERROR", 
            message: result.error || "Payment processing failed" 
          });
        }

        // Update order payment status
        await updateOrderPaymentStatus(order.id, "completed");

        return { 
          success: true, 
          paymentId: result.paymentId,
          orderNumber: input.orderNumber,
        };
      }),

    // Admin procedures
    list: protectedProcedure.query(async ({ ctx }) => {
      if (ctx.user.role !== 'admin') {
        throw new TRPCError({ code: "FORBIDDEN", message: "Admin access required" });
      }
      return await getAllOrders();
    }),

    filter: protectedProcedure
      .input(z.object({
        startDate: z.string().optional(),
        endDate: z.string().optional(),
        paymentStatus: z.enum(["pending", "completed", "failed"]).optional(),
        status: z.enum(["pending", "processing", "shipped", "delivered", "cancelled"]).optional(),
      }))
      .query(async ({ ctx, input }) => {
        if (ctx.user.role !== 'admin') {
          throw new TRPCError({ code: "FORBIDDEN", message: "Admin access required" });
        }

        const filters: any = {};
        if (input.startDate) filters.startDate = new Date(input.startDate);
        if (input.endDate) filters.endDate = new Date(input.endDate);
        if (input.paymentStatus) filters.paymentStatus = input.paymentStatus;
        if (input.status) filters.status = input.status;

        return await getFilteredOrders(filters);
      }),

    updateStatus: protectedProcedure
      .input(z.object({
        orderId: z.number(),
        status: z.enum(["pending", "processing", "shipped", "delivered", "cancelled"]),
        trackingNumber: z.string().optional(),
      }))
      .mutation(async ({ ctx, input }) => {
        if (ctx.user.role !== 'admin') {
          throw new TRPCError({ code: "FORBIDDEN", message: "Admin access required" });
        }
        await updateOrderStatus(input.orderId, input.status, input.trackingNumber);
        return { success: true };
      }),

    updatePaymentStatus: protectedProcedure
      .input(z.object({
        orderId: z.number(),
        paymentStatus: z.enum(["pending", "completed", "failed"]),
      }))
      .mutation(async ({ ctx, input }) => {
        if (ctx.user.role !== 'admin') {
          throw new TRPCError({ code: "FORBIDDEN", message: "Admin access required" });
        }
        await updateOrderPaymentStatus(input.orderId, input.paymentStatus);
        return { success: true };
      }),

    captureAbandonedCart: publicProcedure
      .input(z.object({
        customerEmail: z.string().email(),
        customerName: z.string().optional(),
        cartItems: z.array(z.object({
          productId: z.number(),
          productName: z.string(),
          quantity: z.number(),
          pricePerUnit: z.number(),
        })),
        totalAmount: z.number(),
      }))
      .mutation(async ({ input }) => {
        await upsertAbandonedCart({
          customerEmail: input.customerEmail,
          customerName: input.customerName || null,
          cartData: JSON.stringify(input.cartItems),
          totalAmount: input.totalAmount,
        });
        return { success: true };
      }),
  }),

  
  storage: router({
    upload: protectedProcedure
      .input(z.object({
        key: z.string(),
        data: z.array(z.number()),
        contentType: z.string().optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        if (ctx.user.role !== 'admin') {
          throw new TRPCError({ code: "FORBIDDEN", message: "Admin access required" });
        }
        
        const { storagePut } = await import("./storage");
        const buffer = new Uint8Array(input.data);
        const result = await storagePut(input.key, buffer, input.contentType);
        
        return result;
      }),
  }),
  
  contact: router({
    submit: publicProcedure
      .input(z.object({
        name: z.string().min(1, "Name is required"),
        email: z.string().email("Valid email is required"),
        phone: z.string().optional(),
        subject: z.string().min(1, "Subject is required"),
        message: z.string().min(10, "Message must be at least 10 characters"),
      }))
      .mutation(async ({ input }) => {
        const { createContactSubmission } = await import("./db");
        const submission = await createContactSubmission(input);
        
        // Optionally notify owner
        try {
          const { notifyOwner } = await import("./_core/notification");
          await notifyOwner({
            title: `New Contact Form Submission from ${input.name}`,
            content: `Subject: ${input.subject}\n\nMessage: ${input.message}\n\nEmail: ${input.email}${input.phone ? `\nPhone: ${input.phone}` : ''}`,
          });
        } catch (error) {
          console.error("Failed to send notification:", error);
        }
        
        return { success: true, id: submission.id };
      }),
    
    list: protectedProcedure
      .query(async ({ ctx }) => {
        if (ctx.user.role !== 'admin') {
          throw new TRPCError({ code: "FORBIDDEN", message: "Admin access required" });
        }
        
        const { getAllContactSubmissions } = await import("./db");
        return await getAllContactSubmissions();
      }),
    
    updateStatus: protectedProcedure
      .input(z.object({
        id: z.number(),
        status: z.enum(["new", "read", "replied"]),
        adminNotes: z.string().optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        if (ctx.user.role !== 'admin') {
          throw new TRPCError({ code: "FORBIDDEN", message: "Admin access required" });
        }
        
        const { updateContactSubmissionStatus } = await import("./db");
        await updateContactSubmissionStatus(input.id, input.status, input.adminNotes);
        
        return { success: true };
      }),
  }),

  square: router({
    createPayment: publicProcedure
      .input(z.object({
        sourceId: z.string(),
        amountCents: z.number(),
        orderId: z.string().optional(),
        customerId: z.string().optional(),
        note: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        const { createSquarePayment } = await import("./_core/square");
        const result = await createSquarePayment({
          sourceId: input.sourceId,
          amountCents: input.amountCents,
          orderId: input.orderId,
          customerId: input.customerId,
          note: input.note,
        });
        
        if (!result.success) {
          throw new TRPCError({
            code: "BAD_REQUEST",
            message: result.error || "Payment failed",
          });
        }
        
        return result;
      }),
    
    getPayment: publicProcedure
      .input(z.object({ paymentId: z.string() }))
      .query(async ({ input }) => {
        const { getSquarePayment } = await import("./_core/square");
        const result = await getSquarePayment(input.paymentId);
        
        if (!result.success) {
          throw new TRPCError({
            code: "NOT_FOUND",
            message: result.error || "Payment not found",
          });
        }
        
        return result;
      }),
    
    refundPayment: protectedProcedure
      .input(z.object({
        paymentId: z.string(),
        amountCents: z.number(),
        reason: z.string().optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        if (ctx.user.role !== 'admin') {
          throw new TRPCError({ code: "FORBIDDEN", message: "Admin access required" });
        }
        
        const { refundSquarePayment } = await import("./_core/square");
        const result = await refundSquarePayment({
          paymentId: input.paymentId,
          amountCents: input.amountCents,
          reason: input.reason,
        });
        
        if (!result.success) {
          throw new TRPCError({
            code: "BAD_REQUEST",
            message: result.error || "Refund failed",
          });
        }
        
        return result;
      }),
  }),
});

export type AppRouter = typeof appRouter;
