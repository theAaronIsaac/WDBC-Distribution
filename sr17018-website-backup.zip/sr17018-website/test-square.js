const { Client } = require('square');
const client = new Client({ accessToken: 'test', environment: 'sandbox' });
console.log('Has paymentsApi:', !!client.paymentsApi);
console.log('Has refundsApi:', !!client.refundsApi);
